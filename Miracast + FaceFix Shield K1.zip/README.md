# Magisk Miracast & FaceFix for Shield K1

This Module adds the necessary Lines/Files to Enable Miracast on the K1 and additionally fix the FaceLock Crash on the last Stable Nvidia Build 5.2

After installing and rebooting, go to Settings > Display > Cast > Click the 3 dots > Enable Wireless Display > Done.

